#include "header.h"

int main(){
	menuAwal();
	return 0;
}
